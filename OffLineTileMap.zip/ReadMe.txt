
To change texts and layout you basically only need to edit the index.htm file and the
res/index.js file. Anything else is a bit risky...

The service runs off-line in a supported web browser by opening the index.htm file.
Additional map tiles can be added to the tiles folder.



=======================  SNABBSTART  ===============================================

Dubbelklicka p� "index.htm" och se kartorna i din webbl�sare.
T�ckning finns �ver Sverige ner till skala runt 1:50'000.

=======================  LITE MERA  ================================================

Det g�r att zooma och panorera, samt rotera kartan p� samma s�tt som i
karttj�nster p� Internet. Om man vill kan man visa kartan i fullsk�rmsl�ge ocks�.

Ett "klick" i kartan skapar en etikett med koordinater f�r platsen.Dessa rensas
med en knapp uppe till h�ger i gr�nssnittet. Ett klick p� "F�rsvarsmakten" 
�terst�ller allt. Beroende p� vilken webbl�sare som anv�nds s� kan vissa funktioner 
vara avst�ngda. F�r att kartorna skall visas kr�vs att javascript �r aktiverat.

Anv�nd sk�rmklippverktyget f�r att skapa en bild f�r en presentation eller
f�r att infoga i ett dokument.

====================================================================================

-------------------------  CAVEATS -------------------------------------------------

Observera att detta inte �r ett GIS, eller ens ett program. Det �r en kartprodukt
byggd f�r att visas i en webbl�sare utan installation och d�rf�r �r den ganska begr�nsad.
Att skapa en kopia p� stickan g�r att g�ra men tar mycket plats (minst 25 GB) och
d� det �r v�ldigt m�nga filer (�ver 1,3 miljoner) s� tar kopiering l�ng tid.
Det g�r att placera inneh�llet p� ett n�tverk, men utan en riktig kartserver s�
�r det inte att rekommendera. Kartorna passar b�st att anv�ndas av en person �t g�ngen.

Allt fungerar eftersom webbl�saren kan l�sa instruktionerna i flera javascriptfiler.
Det finns ett antal grundfunktioner i ett antal filer, men �ven konfigurationen av
karttj�nsten �r skriven i javascript. Om din webbl�sare �r inst�lld p� att inte exekvera
javascript s� kommer kartorna inte att fungera. Kartorna kr�ver dock inte mer r�ttigheter
�n vad som redan kr�vs f�r EMILIA och VIDAR.

Detta sagt, s� �r kartorna (produkten) officiellt sanktionerad av F�rsvarsmakten.
Att "k�ra" javascript i en webbl�sare g�rs varje dag i din dator, riskerna att k�ra
lokala skriptfiler p� det h�r s�ttet �r f�rsumbara. Webbl�saren �r byggd f�r detta.
Kartorna och det som visas �r samma som redan anv�nds i FM, koordinaterna �r s�
korrekta man kan f�rv�nta sig, men �ven om de flesta skriptfilerna redan finns p�
FM-AP, s� �r de som finns i mappen "res" p� stickan som sagt inte formellt godk�nnda.

Kartorna �r begr�nsade till Sverige (i b�ttre uppl�sning) och enbart till och med
terr�ngkartan 1:50'000. Det g�r att rendera kartor f�r fler omr�den och skalor, men
detta �r tidskr�vande och tar mycket utrymme. Varje ny zoom-niv� med h�gre detaljgrad
genererar fyra g�nger s� mycket data som den f�reg�ende niv�n, f�r samma omr�de.
Ytterligare en zoom-niv� �ver Sverige skulle generera i storleksordningen 60 GB ytterligare.

-------------------------------------------------------------------------------------
